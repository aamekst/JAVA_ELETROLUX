package br.com.eletrolux.teste;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.eletrolux.beans.Fogao;

public class ProgramaFogao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Fogao fogao =  new Fogao();
		
		fogao.setNome("Geladeira xr");
		fogao.setPeso(490);
		fogao.setQtdBoca(4);
		
		List<Fogao> fogaoArray = new ArrayList<Fogao>();
		fogaoArray.add(fogao);
		
		for(Fogao f : fogaoArray)
		{
			System.out.println("Nome: " + f.getNome() + "\nPeso:" + f.getPeso() + "\nQuantidade de bocas: " +f.getQtdBoca());
		}
		
		
	

	}

}
