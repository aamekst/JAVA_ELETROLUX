package br.com.eletrolux.beans;

public class Geladeira extends Eletrodomestico {
	
	private int qtdPorta;
	private double volume;
	
	public int getQtdPorta() {
		return qtdPorta;
	}
	public void setQtdPorta(int qtdPorta) {
		this.qtdPorta = qtdPorta;
	}
	public double getVolume() {
		return volume;
	}
	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String mostrarAtributos()
	{
		return "O peso: " + getPeso()+ "\n Nome: " + getNome() + "\n Quantidade de portas: " + getQtdPorta() + "\n Volume: " + getVolume();
	}
	
}
