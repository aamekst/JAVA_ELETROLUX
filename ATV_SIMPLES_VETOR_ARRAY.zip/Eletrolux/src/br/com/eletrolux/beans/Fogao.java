package br.com.eletrolux.beans;

public class Fogao extends Eletrodomestico{

	private int qtdBoca;

	public int getQtdBoca() {
		return qtdBoca;
	}

	public void setQtdBoca(int qtdBoca) {
		this.qtdBoca = qtdBoca;
	}
	
	public String mostrarAtributos()
	{
		return "O peso: " + getPeso()+ "\n Nome: " + getNome() + "\n Quantidade de bocas: " + getQtdBoca();
	}
	
	
}
