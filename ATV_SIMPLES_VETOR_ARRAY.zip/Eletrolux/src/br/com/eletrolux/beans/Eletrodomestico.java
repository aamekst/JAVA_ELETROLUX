package br.com.eletrolux.beans;

public class Eletrodomestico {
	
	private String nome;
	private double peso;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	
	public String mostrarAtributos()
	{
		return "O peso: " + getPeso()+ "\n Nome: " + getNome();
	}

	

}
