package br.com.eletrolux.teste;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.eletrolux.beans.Geladeira;


public class ProgramaGeladeira {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Geladeira geladeira =  new Geladeira();
		
		geladeira.setNome("Geladeira xr");
		geladeira.setPeso(490);
		geladeira.setQtdPorta(3);
		geladeira.setVolume(6000);
		
		List<Geladeira> geladeiraArray = new ArrayList<Geladeira>();
		geladeiraArray.add(geladeira);
		
		for(Geladeira g : geladeiraArray)
		{
			System.out.println("Nome: " + g.getNome() + "\nPeso:" + g.getPeso() + "\nQuantidade de portas: " + g.getQtdPorta() +  "\nVolume:" + g.getVolume());
		}
	}

}
