package br.com.eletrolux.teste;

import javax.swing.JOptionPane;

import br.com.eletrolux.beans.Fogao;

public class ProgramaFogao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int qtdBocas=0, resp=0, indice=0;
		double peso=0;
		String nome=null;
		
		
		Fogao[] fogao = new Fogao[3];
		
		while(resp==0)
		{
		  nome = JOptionPane.showInputDialog("Nome do eletrodomestico: " );
		  qtdBocas = Integer.parseInt(JOptionPane.showInputDialog("Quantidade de bocas do fogão: "));
		  peso = Double.parseDouble(JOptionPane.showInputDialog("Peso: "));
	
		  fogao[indice] = new Fogao();
		  fogao[indice] .setNome(nome);
		  fogao[indice] .setPeso(peso);
		  fogao[indice] .setQtdBoca(qtdBocas);
		  
		  indice+=1;
		  
		  
		  resp = JOptionPane.showConfirmDialog(
					null, "Deseja continuar?", "CAMADAS", 
					JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE);
		  

		  
		  for(int i =0; i<indice; i++)
		  {
			  System.out.println("\n Nome: " + fogao[i].getNome() + "\n Peso: " + fogao[i].getPeso() + "\n Quantidade de bocas: " + fogao[i].getQtdBoca());
		  }
		 
		}

	}

}
