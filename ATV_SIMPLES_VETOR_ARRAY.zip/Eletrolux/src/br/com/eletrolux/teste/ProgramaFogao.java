package br.com.eletrolux.teste;

import javax.swing.JOptionPane;

import br.com.eletrolux.beans.Fogao;

public class ProgramaFogao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Fogao fogao = new Fogao();
		
		String nome = JOptionPane.showInputDialog("Nome do eletrodomestico: " );
		int qtdbocas = Integer.parseInt(JOptionPane.showInputDialog("Quantidade de bocas do fogão: "));
		double peso = Double.parseDouble(JOptionPane.showInputDialog("Peso: "));
	
		System.out.println("Nome: " + nome + "\n Quantidade de bocas do fogão: " + qtdbocas + "\n Peso: " + peso);

	}

}
