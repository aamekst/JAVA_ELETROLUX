package br.com.eletrolux.teste;

import javax.swing.JOptionPane;

import br.com.eletrolux.beans.Geladeira;

public class ProgramaGeladeira {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Geladeira geladeira = new Geladeira();
		
		String nome = JOptionPane.showInputDialog("Nome do eletrodomestico: " );
		int qtdportas = Integer.parseInt(JOptionPane.showInputDialog("Quantidade de portas da geladeira: "));
		double peso = Double.parseDouble(JOptionPane.showInputDialog("Peso: "));
		double volume = Double.parseDouble(JOptionPane.showInputDialog("Volume: "));
		
	
		System.out.println("Nome: " + nome + "\n Quantidade de portas da geladeira: " + qtdportas + "\n Peso: " + peso + "\n Volume: " + volume);
	}

}
