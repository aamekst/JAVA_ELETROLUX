package br.com.eletrolux.teste;

import javax.swing.JOptionPane;


import br.com.eletrolux.beans.Geladeira;

public class ProgramaGeladeira {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int qtdportas=0, resp=0, indice=0;
		double peso=0, volume =0;
		String nome=null;
		
		
		Geladeira[] geladeira = new Geladeira[3];
		
		while(resp==0)
		{
		  nome = JOptionPane.showInputDialog("Nome do eletrodomestico: " );
		  qtdportas = Integer.parseInt(JOptionPane.showInputDialog("Quantidade de portas da geladeira: "));
		  peso = Double.parseDouble(JOptionPane.showInputDialog("Peso: "));
		  volume = Double.parseDouble(JOptionPane.showInputDialog("Volume: "));
	
		  geladeira[indice] = new Geladeira();
		  geladeira[indice] .setNome(nome);
		  geladeira[indice] .setPeso(peso);
		  geladeira[indice] .setVolume(volume);
		  geladeira[indice] .setQtdPorta(qtdportas);
		  
		  indice+=1;
		  
		  
		  resp = JOptionPane.showConfirmDialog(
					null, "Deseja continuar?", "CAMADAS", 
					JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE);
		  

		  
		  for(int i =0; i<indice; i++)
		  {
			  System.out.println("\n Nome: " + geladeira[i].getNome() + "\n Peso: " + geladeira[i].getPeso() + "\n Quantidade de bocas: " + geladeira[i].getQtdPorta() + "\n Volume: " + geladeira[i].getVolume());
		  }
		 
		}
	}

}
